package com.yeyuhao1234.CloudGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
